#!/bin/sh
scp *.dtd alnilam:/var/www/docs/schemata/
scp *.xsd alnilam:/var/www/docs/schemata/
